function give:glistering_melon_slice
function give:enchanted_glistering_melon_slice

give @s minecraft:golden_carrot
function give:enchanted_golden_carrot

give @s minecraft:golden_apple
give @s minecraft:enchanted_golden_apple

function give:golden_cooked_beef
function give:enchanted_golden_cooked_beef

function give:golden_cooked_chicken
function give:enchanted_golden_cooked_chicken

function give:golden_cooked_cod
function give:enchanted_golden_cooked_cod

function give:golden_cooked_mutton
function give:enchanted_golden_cooked_mutton

function give:golden_cooked_rabbit
function give:enchanted_golden_cooked_rabbit

function give:golden_cooked_salmon
function give:enchanted_golden_cooked_salmon







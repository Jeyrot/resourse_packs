# Spawn the snow block display
summon block_display ~ ~-.5 ~ {\
    block_state:{id:"minecraft:snow",properties:{layers:"1"}},\
    transformation:{\
        left_rotation:[0f,0f,0f,1f],\
        right_rotation:[0f,0f,0f,1f],\
        translation:[-.5f,.5f,0f],\
        scale:[1f,1f,.5f]\
    },\
    Passengers:[\
    {\
            id:"minecraft:block_display",\
            block_state:{id:"minecraft:snow",properties:{layers:"1"}},\
            transformation:{\
                left_rotation:[0f,0f,0f,1f],\
                right_rotation:[0f,0f,0f,1f],\
                translation:[-.5f,.5f,-.5f],\
                scale:[.5f,1f,.5f]\
            },\
            Tags:["snow_on_stairs.snow","snow_on_stairs.stair.outer_right"]\
        },\
        {\
            id:"minecraft:block_display",\
            block_state:{id:"minecraft:snow",properties:{layers:"1"}},\
            transformation:{\
                left_rotation:[-0.7f,0f,0f,0.7f],\
                right_rotation:[0f,0f,0f,1f],\
                translation:[0f,.625f,0.125f],\
                scale:[.5f,1f,.5f]\
            },\
            Tags:["snow_on_stairs.snow","snow_on_stairs.stair.outer_right"]\
        },\
        {\
            id:"minecraft:block_display",\
            block_state:{id:"minecraft:snow",properties:{layers:"1"}},\
            transformation:{\
                left_rotation:[0f,0f,1f,1f],\
                right_rotation:[0f,0f,0f,1f],\
                translation:[0f,.625f,-.5f],\
                scale:[.5f,1f,.625f]\
            },\
            Tags:["snow_on_stairs.snow","snow_on_stairs.stair.outer_right"]\
        },\
        {\
            id:"minecraft:block_display",\
            block_state:{id:"minecraft:snow",properties:{layers:"1"}},\
            transformation:{\
                left_rotation:[0f,0f,0f,1f],\
                right_rotation:[0f,0f,0f,1f],\
                translation:[0f,1f,-.5f],\
                scale:[.5f,1f,.5f]\
            },\
            Tags:["snow_on_stairs.snow","snow_on_stairs.stair.outer_right"]\
        },\
        {\
            id:"minecraft:interaction",\
            width:1.05f,\
            height:0.25f,\  
            response: 1b,\
            Tags:["snow_on_stairs.snow","snow_on_stairs.stair.outer_right"]\
        }\
    ],\
    Tags: ["snow_on_stairs.snow","snow_on_stairs.stair.outer_right"] \
}

# Rotate the snow block display according to stair rotation
execute positioned ~ ~-.5 ~ run function snow_on_stairs:place/snow/stair/util/set_rotation
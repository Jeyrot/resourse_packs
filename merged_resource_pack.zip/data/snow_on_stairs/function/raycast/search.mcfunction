# Decrement raycast steps
scoreboard players remove @s snow_on_stairs.raycast.steps 1

# Check if a valid block has been hit and place snow accordingly
execute align xyz positioned ~.5 ~.5 ~.5 \
    if predicate snow_on_stairs:valid_for_snow_placement \
    unless entity @e[tag=snow_on_stairs.snow,distance=..0.99,type=minecraft:interaction] \
    rotated ~ 0 \
        if block ^ ^ ^-1 minecraft:snow \
        run return run function snow_on_stairs:place/check

# Continue the raycast if steps remain
execute if score @s snow_on_stairs.raycast.steps matches 1.. if score @s snow_on_stairs.raycast.hit matches 0.. positioned ^ ^ ^.1 run function snow_on_stairs:raycast/search